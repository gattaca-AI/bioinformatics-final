from translational_sw.align import (
    identity_fraction,
    simple_substitution_score,
    smith_waterman,
)
from translational_sw.blosum62 import blosum62_score


def test_local_alignment_ignores_unrelated_flanks():
    result = smith_waterman(
        "XXXXMEEPQSDPSVYYYY",
        "AAAMEEPQSDPSVBBB",
        substitution_score=simple_substitution_score(match=2, mismatch=-1),
        gap_penalty=-2,
    )

    assert result.aligned_a == "MEEPQSDPSV"
    assert result.aligned_b == "MEEPQSDPSV"
    assert result.score == 20
    assert result.start_a == 4
    assert result.end_a == 14
    assert result.start_b == 3
    assert result.end_b == 13


def test_traceback_represents_internal_deletion_as_gap():
    result = smith_waterman(
        "AAACDEFGGG",
        "TTTCDFGTTT",
        substitution_score=simple_substitution_score(match=3, mismatch=-2),
        gap_penalty=-3,
    )

    assert result.aligned_a == "CDEFG"
    assert result.aligned_b == "CD-FG"
    assert result.identity == 4 / 5


def test_blosum62_scores_conservative_substitution_above_nonconservative():
    assert blosum62_score("L", "I") > blosum62_score("L", "W")
    assert blosum62_score("A", "A") > blosum62_score("A", "G")


def test_normalized_conservation_score_is_bounded_and_exact_match_is_one():
    exact = smith_waterman(
        "ACDEFG",
        "ACDEFG",
        substitution_score=blosum62_score,
        gap_penalty=-6,
        normalize=True,
    )
    partial = smith_waterman(
        "ACDEFG",
        "ACDYYY",
        substitution_score=blosum62_score,
        gap_penalty=-6,
        normalize=True,
    )

    assert exact.normalized_score == 1.0
    assert 0.0 <= partial.normalized_score <= 1.0
    assert partial.normalized_score < exact.normalized_score


def test_identity_fraction_ignores_gap_columns_for_denominator():
    assert identity_fraction("AC-DE", "ACGDE") == 4 / 5
    assert identity_fraction("----", "ACGT") == 0.0
