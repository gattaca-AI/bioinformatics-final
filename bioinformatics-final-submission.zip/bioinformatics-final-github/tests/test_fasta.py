from translational_sw.fasta import FastaRecord, parse_fasta, write_fasta


def test_parse_fasta_reads_multiple_records_and_removes_whitespace():
    text = """>seq1 first sequence
    ACD E
    FGH
    >seq2
    MNP
    Q
    """

    records = parse_fasta(text)

    assert records == [
        FastaRecord(identifier="seq1", description="first sequence", sequence="ACDEFGH"),
        FastaRecord(identifier="seq2", description="", sequence="MNPQ"),
    ]


def test_write_fasta_wraps_sequence_lines():
    text = write_fasta(
        [FastaRecord(identifier="seq1", description="example", sequence="ABCDEFGHIJK")],
        line_width=4,
    )

    assert text == ">seq1 example\nABCD\nEFGH\nIJK\n"
