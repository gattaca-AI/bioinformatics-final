from __future__ import annotations

import json
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any


UNIPROT_SEARCH_URL = "https://rest.uniprot.org/uniprotkb/search"
HUMAN_ORGANISM_ID = "9606"
RAT_ORGANISM_ID = "10116"


@dataclass(frozen=True)
class PanelGene:
    symbol: str
    human_gene: str
    rat_gene: str
    pathway_role: str
    rationale: str


@dataclass(frozen=True)
class ProteinRecord:
    panel_symbol: str
    species: str
    gene: str
    accession: str
    entry_name: str
    protein_name: str
    organism_name: str
    length: int
    sequence: str
    reviewed: bool
    pathway_role: str
    rationale: str


PANEL_GENES = [
    PanelGene(
        symbol="CDKN2B/p15",
        human_gene="CDKN2B",
        rat_gene="Cdkn2b",
        pathway_role="cell-cycle brake",
        rationale="p15INK4b inhibits CDK4/6 and supports G1 arrest downstream of TGF-beta/Activin signaling.",
    ),
    PanelGene(
        symbol="INHBA/Activin A",
        human_gene="INHBA",
        rat_gene="Inhba",
        pathway_role="fibrosis/regeneration ligand",
        rationale="INHBA encodes the activin beta A subunit, a ligand implicated in inflammation, fibrosis, and growth control.",
    ),
    PanelGene(
        symbol="ACVR2A",
        human_gene="ACVR2A",
        rat_gene="Acvr2a",
        pathway_role="Activin receptor",
        rationale="Type II receptor that binds activins and initiates SMAD signaling.",
    ),
    PanelGene(
        symbol="ACVR2B",
        human_gene="ACVR2B",
        rat_gene="Acvr2b",
        pathway_role="Activin receptor",
        rationale="Alternative type II Activin receptor relevant to ligand responsiveness.",
    ),
    PanelGene(
        symbol="SMAD2",
        human_gene="SMAD2",
        rat_gene="Smad2",
        pathway_role="signal transducer",
        rationale="Canonical intracellular mediator of Activin/TGF-beta signaling.",
    ),
    PanelGene(
        symbol="SMAD3",
        human_gene="SMAD3",
        rat_gene="Smad3",
        pathway_role="signal transducer",
        rationale="Canonical mediator linked to fibrogenic transcriptional responses.",
    ),
    PanelGene(
        symbol="TGFB1",
        human_gene="TGFB1",
        rat_gene="Tgfb1",
        pathway_role="fibrosis ligand",
        rationale="Major profibrotic cytokine that overlaps mechanistically with Activin/SMAD signaling.",
    ),
    PanelGene(
        symbol="COL1A1",
        human_gene="COL1A1",
        rat_gene="Col1a1",
        pathway_role="fibrosis matrix output",
        rationale="Type I collagen is a structural marker and output of liver fibrogenesis.",
    ),
    PanelGene(
        symbol="ACTA2",
        human_gene="ACTA2",
        rat_gene="Acta2",
        pathway_role="activated myofibroblast marker",
        rationale="Alpha-smooth muscle actin marks activated hepatic stellate cells/myofibroblasts in fibrosis.",
    ),
    PanelGene(
        symbol="CCND1",
        human_gene="CCND1",
        rat_gene="Ccnd1",
        pathway_role="cell-cycle progression",
        rationale="Cyclin D1 promotes G1/S progression and complements the p15 cell-cycle brake.",
    ),
]


def fetch_uniprot_protein(gene: str, organism_id: str, reviewed_only: bool = True) -> ProteinRecord | None:
    query = f"gene_exact:{gene} AND organism_id:{organism_id}"
    if reviewed_only:
        query += " AND reviewed:true"
    payload = _uniprot_search(query)
    results = payload.get("results", [])
    if not results and reviewed_only:
        return fetch_uniprot_protein(gene, organism_id, reviewed_only=False)
    if not results:
        return None
    return _protein_record_from_uniprot(results[0], gene, organism_id)


def fetch_panel_records() -> list[ProteinRecord]:
    records: list[ProteinRecord] = []
    for panel_gene in PANEL_GENES:
        for species, gene, organism_id in [
            ("human", panel_gene.human_gene, HUMAN_ORGANISM_ID),
            ("rat", panel_gene.rat_gene, RAT_ORGANISM_ID),
        ]:
            record = fetch_uniprot_protein(gene, organism_id)
            if record is None:
                raise RuntimeError(f"No UniProt record found for {species} {gene}")
            records.append(
                ProteinRecord(
                    panel_symbol=panel_gene.symbol,
                    species=species,
                    gene=gene,
                    accession=record.accession,
                    entry_name=record.entry_name,
                    protein_name=record.protein_name,
                    organism_name=record.organism_name,
                    length=record.length,
                    sequence=record.sequence,
                    reviewed=record.reviewed,
                    pathway_role=panel_gene.pathway_role,
                    rationale=panel_gene.rationale,
                )
            )
    return records


def _uniprot_search(query: str) -> dict[str, Any]:
    params = {
        "query": query,
        "format": "json",
        "size": "1",
        "fields": "accession,reviewed,id,protein_name,gene_names,organism_name,length,sequence",
    }
    url = f"{UNIPROT_SEARCH_URL}?{urllib.parse.urlencode(params)}"
    request = urllib.request.Request(url, headers={"User-Agent": "translational-sw-project/1.0"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.loads(response.read().decode("utf-8"))


def _protein_record_from_uniprot(payload: dict[str, Any], gene: str, organism_id: str) -> ProteinRecord:
    sequence_payload = payload.get("sequence", {})
    organism_payload = payload.get("organism", {})
    protein_description = payload.get("proteinDescription", {})
    recommended_name = protein_description.get("recommendedName", {})
    full_name = recommended_name.get("fullName", {})
    protein_name = full_name.get("value") or payload.get("uniProtkbId", "")
    organism_name = organism_payload.get("scientificName", organism_id)
    species = "human" if organism_id == HUMAN_ORGANISM_ID else "rat"

    return ProteinRecord(
        panel_symbol=gene,
        species=species,
        gene=gene,
        accession=payload["primaryAccession"],
        entry_name=payload.get("uniProtkbId", ""),
        protein_name=protein_name,
        organism_name=organism_name,
        length=int(sequence_payload.get("length", 0)),
        sequence=sequence_payload.get("value", ""),
        reviewed="reviewed" in payload.get("entryType", "").lower(),
        pathway_role="",
        rationale="",
    )
