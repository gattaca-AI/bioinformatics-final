"""Tools for translational Smith-Waterman sequence analysis."""

