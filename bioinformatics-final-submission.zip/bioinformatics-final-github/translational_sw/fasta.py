from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class FastaRecord:
    identifier: str
    description: str
    sequence: str


def parse_fasta(text: str) -> list[FastaRecord]:
    records: list[FastaRecord] = []
    current_header: str | None = None
    current_sequence: list[str] = []

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith(">"):
            if current_header is not None:
                records.append(_record_from_parts(current_header, current_sequence))
            current_header = line[1:].strip()
            current_sequence = []
        else:
            current_sequence.append("".join(line.split()))

    if current_header is not None:
        records.append(_record_from_parts(current_header, current_sequence))

    return records


def write_fasta(records: list[FastaRecord], line_width: int = 80) -> str:
    chunks: list[str] = []
    for record in records:
        header = record.identifier
        if record.description:
            header = f"{header} {record.description}"
        chunks.append(f">{header}")
        sequence = record.sequence
        for index in range(0, len(sequence), line_width):
            chunks.append(sequence[index : index + line_width])
    return "\n".join(chunks) + "\n"


def _record_from_parts(header: str, sequence_parts: list[str]) -> FastaRecord:
    identifier, _, description = header.partition(" ")
    return FastaRecord(
        identifier=identifier,
        description=description,
        sequence="".join(sequence_parts).upper(),
    )
