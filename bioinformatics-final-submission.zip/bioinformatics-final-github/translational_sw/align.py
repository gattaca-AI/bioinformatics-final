from __future__ import annotations

from dataclasses import dataclass
from typing import Callable


SubstitutionScore = Callable[[str, str], int]


@dataclass(frozen=True)
class AlignmentResult:
    score: int
    normalized_score: float
    aligned_a: str
    aligned_b: str
    start_a: int
    end_a: int
    start_b: int
    end_b: int
    identity: float
    score_matrix: list[list[int]]


def simple_substitution_score(match: int = 2, mismatch: int = -1) -> SubstitutionScore:
    def score(a: str, b: str) -> int:
        return match if a == b else mismatch

    return score


def identity_fraction(aligned_a: str, aligned_b: str) -> float:
    if not aligned_a or len(aligned_a) != len(aligned_b):
        return 0.0
    matches = sum(1 for a, b in zip(aligned_a, aligned_b) if a == b and a != "-" and b != "-")
    return matches / len(aligned_a)


def smith_waterman(
    seq_a: str,
    seq_b: str,
    substitution_score: SubstitutionScore,
    gap_penalty: int,
    normalize: bool = False,
) -> AlignmentResult:
    """Return the best local alignment between two sequences.

    This is the classic Smith-Waterman recurrence with a zero floor:
    H[i,j] = max(0, diagonal + substitution, up + gap, left + gap).
    """

    seq_a = seq_a.upper()
    seq_b = seq_b.upper()
    rows = len(seq_a) + 1
    cols = len(seq_b) + 1
    scores = [[0 for _ in range(cols)] for _ in range(rows)]
    traceback = [["" for _ in range(cols)] for _ in range(rows)]

    best_score = 0
    best_i = 0
    best_j = 0

    for i in range(1, rows):
        for j in range(1, cols):
            diagonal = scores[i - 1][j - 1] + substitution_score(seq_a[i - 1], seq_b[j - 1])
            up = scores[i - 1][j] + gap_penalty
            left = scores[i][j - 1] + gap_penalty
            value = max(0, diagonal, up, left)
            scores[i][j] = value

            if value == 0:
                traceback[i][j] = ""
            elif value == diagonal:
                traceback[i][j] = "diag"
            elif value == up:
                traceback[i][j] = "up"
            else:
                traceback[i][j] = "left"

            if value > best_score:
                best_score = value
                best_i = i
                best_j = j

    aligned_a: list[str] = []
    aligned_b: list[str] = []
    i = best_i
    j = best_j

    while i > 0 and j > 0 and scores[i][j] > 0:
        direction = traceback[i][j]
        if direction == "diag":
            aligned_a.append(seq_a[i - 1])
            aligned_b.append(seq_b[j - 1])
            i -= 1
            j -= 1
        elif direction == "up":
            aligned_a.append(seq_a[i - 1])
            aligned_b.append("-")
            i -= 1
        elif direction == "left":
            aligned_a.append("-")
            aligned_b.append(seq_b[j - 1])
            j -= 1
        else:
            break

    aligned_a_str = "".join(reversed(aligned_a))
    aligned_b_str = "".join(reversed(aligned_b))
    normalized = _normalized_score(seq_a, seq_b, best_score, substitution_score) if normalize else 0.0

    return AlignmentResult(
        score=best_score,
        normalized_score=normalized,
        aligned_a=aligned_a_str,
        aligned_b=aligned_b_str,
        start_a=i,
        end_a=best_i,
        start_b=j,
        end_b=best_j,
        identity=identity_fraction(aligned_a_str, aligned_b_str),
        score_matrix=scores,
    )


def _normalized_score(
    seq_a: str,
    seq_b: str,
    observed_score: int,
    substitution_score: SubstitutionScore,
) -> float:
    denominator = min(_self_score(seq_a, substitution_score), _self_score(seq_b, substitution_score))
    if denominator <= 0:
        return 0.0
    return max(0.0, min(1.0, observed_score / denominator))


def _self_score(sequence: str, substitution_score: SubstitutionScore) -> int:
    return sum(max(0, substitution_score(residue, residue)) for residue in sequence)

