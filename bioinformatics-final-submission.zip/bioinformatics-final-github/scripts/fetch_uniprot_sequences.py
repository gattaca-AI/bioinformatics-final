from __future__ import annotations

import csv
from pathlib import Path

from translational_sw.fasta import FastaRecord, write_fasta
from translational_sw.panel import ProteinRecord, fetch_panel_records


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
FASTA_PATH = DATA_DIR / "panel_sequences.fasta"
METADATA_PATH = DATA_DIR / "panel_metadata.csv"


def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    records = fetch_panel_records()
    _write_metadata(records)
    _write_fasta(records)
    print(f"Fetched {len(records)} protein sequences")
    print(f"Wrote {METADATA_PATH}")
    print(f"Wrote {FASTA_PATH}")


def _write_metadata(records: list[ProteinRecord]) -> None:
    fieldnames = [
        "panel_symbol",
        "species",
        "gene",
        "accession",
        "entry_name",
        "protein_name",
        "organism_name",
        "length",
        "reviewed",
        "pathway_role",
        "rationale",
    ]
    with METADATA_PATH.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for record in records:
            writer.writerow({field: getattr(record, field) for field in fieldnames})


def _write_fasta(records: list[ProteinRecord]) -> None:
    fasta_records = [
        FastaRecord(
            identifier=f"{record.species}|{record.gene}|{record.accession}",
            description=f"{record.panel_symbol} {record.protein_name}",
            sequence=record.sequence,
        )
        for record in records
    ]
    FASTA_PATH.write_text(write_fasta(fasta_records), encoding="utf-8")


if __name__ == "__main__":
    main()
