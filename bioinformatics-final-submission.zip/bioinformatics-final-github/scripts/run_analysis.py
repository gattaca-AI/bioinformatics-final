from __future__ import annotations

import csv
import math
import textwrap
from pathlib import Path

import matplotlib.pyplot as plt

from translational_sw.align import AlignmentResult, simple_substitution_score, smith_waterman
from translational_sw.blosum62 import blosum62_score
from translational_sw.fasta import FastaRecord, parse_fasta


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
FIGURES_DIR = RESULTS_DIR / "figures"
FASTA_PATH = DATA_DIR / "panel_sequences.fasta"
METADATA_PATH = DATA_DIR / "panel_metadata.csv"
SUMMARY_PATH = RESULTS_DIR / "alignment_summary.csv"
CROSS_PANEL_PATH = RESULTS_DIR / "cross_panel_scores.csv"
TOP_ALIGNMENTS_PATH = RESULTS_DIR / "top_alignments.txt"

BASELINE_GAP = -2
IMPROVED_GAP = -6


def main() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)

    metadata = _load_metadata()
    sequences = _load_sequences()
    diagonal_rows = _run_diagonal_alignments(metadata, sequences)
    cross_rows = _run_cross_panel_search(metadata, sequences)

    _write_csv(SUMMARY_PATH, diagonal_rows)
    _write_csv(CROSS_PANEL_PATH, cross_rows)
    _write_top_alignments(diagonal_rows)
    _plot_conservation_heatmap(cross_rows)
    _plot_baseline_vs_improved(diagonal_rows)
    _plot_pathway_conservation_map(diagonal_rows)
    _plot_example_matrix(sequences)

    print(f"Wrote {SUMMARY_PATH}")
    print(f"Wrote {CROSS_PANEL_PATH}")
    print(f"Wrote {TOP_ALIGNMENTS_PATH}")
    print(f"Wrote figures to {FIGURES_DIR}")


def _load_metadata() -> list[dict[str, str]]:
    with METADATA_PATH.open(newline="") as handle:
        return list(csv.DictReader(handle))


def _load_sequences() -> dict[tuple[str, str], FastaRecord]:
    records = {}
    for record in parse_fasta(FASTA_PATH.read_text(encoding="utf-8")):
        species, gene, _accession = record.identifier.split("|")
        records[(species, gene)] = record
    return records


def _run_diagonal_alignments(
    metadata: list[dict[str, str]],
    sequences: dict[tuple[str, str], FastaRecord],
) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for panel_symbol in _panel_order(metadata):
        human_meta = _metadata_for(metadata, panel_symbol, "human")
        rat_meta = _metadata_for(metadata, panel_symbol, "rat")
        human = sequences[("human", human_meta["gene"])]
        rat = sequences[("rat", rat_meta["gene"])]

        baseline = smith_waterman(
            rat.sequence,
            human.sequence,
            substitution_score=simple_substitution_score(match=2, mismatch=-1),
            gap_penalty=BASELINE_GAP,
            normalize=True,
        )
        improved = smith_waterman(
            rat.sequence,
            human.sequence,
            substitution_score=blosum62_score,
            gap_penalty=IMPROVED_GAP,
            normalize=True,
        )

        rows.append(
            _alignment_row(
                panel_symbol=panel_symbol,
                pathway_role=human_meta["pathway_role"],
                rat_gene=rat_meta["gene"],
                human_gene=human_meta["gene"],
                rat_accession=rat_meta["accession"],
                human_accession=human_meta["accession"],
                rat_length=len(rat.sequence),
                human_length=len(human.sequence),
                baseline=baseline,
                improved=improved,
            )
        )
    return rows


def _run_cross_panel_search(
    metadata: list[dict[str, str]],
    sequences: dict[tuple[str, str], FastaRecord],
) -> list[dict[str, str]]:
    human_rows = [row for row in metadata if row["species"] == "human"]
    rat_rows = [row for row in metadata if row["species"] == "rat"]
    results: list[dict[str, str]] = []

    for rat_meta in rat_rows:
        rat = sequences[("rat", rat_meta["gene"])]
        for human_meta in human_rows:
            human = sequences[("human", human_meta["gene"])]
            alignment = smith_waterman(
                rat.sequence,
                human.sequence,
                substitution_score=blosum62_score,
                gap_penalty=IMPROVED_GAP,
                normalize=True,
            )
            results.append(
                {
                    "rat_panel_symbol": rat_meta["panel_symbol"],
                    "human_panel_symbol": human_meta["panel_symbol"],
                    "rat_gene": rat_meta["gene"],
                    "human_gene": human_meta["gene"],
                    "improved_score": str(alignment.score),
                    "normalized_conservation": f"{alignment.normalized_score:.4f}",
                    "identity": f"{alignment.identity:.4f}",
                    "alignment_length": str(len(alignment.aligned_a)),
                    "is_expected_pair": str(rat_meta["panel_symbol"] == human_meta["panel_symbol"]),
                }
            )
    return _add_query_ranks(results)


def _alignment_row(
    panel_symbol: str,
    pathway_role: str,
    rat_gene: str,
    human_gene: str,
    rat_accession: str,
    human_accession: str,
    rat_length: int,
    human_length: int,
    baseline: AlignmentResult,
    improved: AlignmentResult,
) -> dict[str, str]:
    return {
        "panel_symbol": panel_symbol,
        "pathway_role": pathway_role,
        "rat_gene": rat_gene,
        "human_gene": human_gene,
        "rat_accession": rat_accession,
        "human_accession": human_accession,
        "rat_length": str(rat_length),
        "human_length": str(human_length),
        "baseline_score": str(baseline.score),
        "baseline_normalized": f"{baseline.normalized_score:.4f}",
        "improved_score": str(improved.score),
        "improved_normalized": f"{improved.normalized_score:.4f}",
        "improved_identity": f"{improved.identity:.4f}",
        "improved_alignment_length": str(len(improved.aligned_a)),
        "rat_aligned_start": str(improved.start_a + 1),
        "rat_aligned_end": str(improved.end_a),
        "human_aligned_start": str(improved.start_b + 1),
        "human_aligned_end": str(improved.end_b),
        "aligned_rat": improved.aligned_a,
        "aligned_human": improved.aligned_b,
    }


def _add_query_ranks(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    grouped: dict[str, list[dict[str, str]]] = {}
    for row in rows:
        grouped.setdefault(row["rat_panel_symbol"], []).append(row)
    for group in grouped.values():
        group.sort(key=lambda row: float(row["normalized_conservation"]), reverse=True)
        for rank, row in enumerate(group, start=1):
            row["rank_for_rat_query"] = str(rank)
    return rows


def _write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    if not rows:
        raise RuntimeError(f"No rows to write to {path}")
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def _write_top_alignments(rows: list[dict[str, str]]) -> None:
    selected = ["CDKN2B/p15", "INHBA/Activin A", "SMAD3", "COL1A1"]
    chunks = [
        "Representative improved Smith-Waterman alignments",
        "Scoring: BLOSUM62 substitution matrix, linear gap penalty -6",
        "",
    ]
    for row in rows:
        if row["panel_symbol"] not in selected:
            continue
        chunks.append(f"## {row['panel_symbol']} ({row['pathway_role']})")
        chunks.append(
            "Rat {rat_gene} {rat_start}-{rat_end} vs human {human_gene} {human_start}-{human_end}; "
            "normalized conservation {norm}; identity {identity}".format(
                rat_gene=row["rat_gene"],
                rat_start=row["rat_aligned_start"],
                rat_end=row["rat_aligned_end"],
                human_gene=row["human_gene"],
                human_start=row["human_aligned_start"],
                human_end=row["human_aligned_end"],
                norm=row["improved_normalized"],
                identity=row["improved_identity"],
            )
        )
        chunks.extend(_format_alignment(row["aligned_rat"], row["aligned_human"]))
        chunks.append("")
    TOP_ALIGNMENTS_PATH.write_text("\n".join(chunks), encoding="utf-8")


def _format_alignment(aligned_a: str, aligned_b: str, width: int = 80) -> list[str]:
    lines: list[str] = []
    for start in range(0, len(aligned_a), width):
        a_chunk = aligned_a[start : start + width]
        b_chunk = aligned_b[start : start + width]
        match_line = "".join("|" if a == b and a != "-" else " " for a, b in zip(a_chunk, b_chunk))
        lines.append(f"rat   {a_chunk}")
        lines.append(f"      {match_line}")
        lines.append(f"human {b_chunk}")
        lines.append("")
    return lines


def _plot_conservation_heatmap(rows: list[dict[str, str]]) -> None:
    rat_labels = _unique_in_order([row["rat_panel_symbol"] for row in rows])
    human_labels = _unique_in_order([row["human_panel_symbol"] for row in rows])
    values = [
        [
            _find_cross_score(rows, rat_label, human_label)
            for human_label in human_labels
        ]
        for rat_label in rat_labels
    ]

    fig, ax = plt.subplots(figsize=(11, 8))
    image = ax.imshow(values, cmap="viridis", vmin=0, vmax=1)
    ax.set_xticks(range(len(human_labels)), labels=human_labels, rotation=45, ha="right")
    ax.set_yticks(range(len(rat_labels)), labels=rat_labels)
    ax.set_xlabel("Human reference proteins")
    ax.set_ylabel("Rat query proteins")
    ax.set_title("Improved Smith-Waterman normalized conservation scores")
    for i, row_values in enumerate(values):
        for j, value in enumerate(row_values):
            color = "white" if value < 0.55 else "black"
            ax.text(j, i, f"{value:.2f}", ha="center", va="center", fontsize=8, color=color)
    cbar = fig.colorbar(image, ax=ax)
    cbar.set_label("Normalized conservation")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "conservation_heatmap.png", dpi=220)
    plt.close(fig)


def _plot_baseline_vs_improved(rows: list[dict[str, str]]) -> None:
    labels = [row["panel_symbol"] for row in rows]
    baseline = [float(row["baseline_normalized"]) for row in rows]
    improved = [float(row["improved_normalized"]) for row in rows]
    x = list(range(len(labels)))
    width = 0.38

    fig, ax = plt.subplots(figsize=(12, 6))
    ax.bar([value - width / 2 for value in x], baseline, width=width, label="Simple match/mismatch")
    ax.bar([value + width / 2 for value in x], improved, width=width, label="BLOSUM62 + normalization")
    ax.set_xticks(x, labels=labels, rotation=45, ha="right")
    ax.set_ylim(0, 1.08)
    ax.set_ylabel("Normalized conservation score")
    ax.set_title("Baseline vs improved Smith-Waterman scoring")
    ax.legend()
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "baseline_vs_improved_scores.png", dpi=220)
    plt.close(fig)


def _plot_pathway_conservation_map(rows: list[dict[str, str]]) -> None:
    scores = {row["panel_symbol"]: float(row["improved_normalized"]) for row in rows}
    positions = {
        "INHBA/Activin A": (0.08, 0.62),
        "ACVR2A": (0.29, 0.76),
        "ACVR2B": (0.29, 0.48),
        "SMAD2": (0.52, 0.76),
        "SMAD3": (0.52, 0.48),
        "CDKN2B/p15": (0.76, 0.78),
        "CCND1": (0.76, 0.57),
        "TGFB1": (0.08, 0.24),
        "COL1A1": (0.76, 0.32),
        "ACTA2": (0.76, 0.14),
    }
    edges = [
        ("INHBA/Activin A", "ACVR2A"),
        ("INHBA/Activin A", "ACVR2B"),
        ("ACVR2A", "SMAD2"),
        ("ACVR2B", "SMAD3"),
        ("SMAD2", "CDKN2B/p15"),
        ("SMAD3", "CDKN2B/p15"),
        ("SMAD3", "COL1A1"),
        ("SMAD3", "ACTA2"),
        ("TGFB1", "SMAD3"),
    ]

    fig, ax = plt.subplots(figsize=(12, 6.7))
    cmap = plt.get_cmap("viridis")
    for source, target in edges:
        x1, y1 = positions[source]
        x2, y2 = positions[target]
        ax.annotate(
            "",
            xy=(x2, y2),
            xytext=(x1, y1),
            arrowprops={"arrowstyle": "->", "color": "#555555", "lw": 1.5},
        )
    for label, (x, y) in positions.items():
        score = scores[label]
        color = cmap(score)
        ax.text(
            x,
            y,
            f"{label}\n{score:.2f}",
            ha="center",
            va="center",
            fontsize=10,
            bbox={
                "boxstyle": "round,pad=0.45",
                "facecolor": color,
                "edgecolor": "#2f2f2f",
                "linewidth": 1.2,
            },
        )
    ax.text(0.5, 0.95, "Activin A-p15/fibrosis pathway panel colored by rat-human conservation", ha="center", fontsize=14)
    ax.text(0.5, 0.02, "Higher values indicate stronger normalized local protein conservation under BLOSUM62 scoring.", ha="center", fontsize=10)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "pathway_conservation_map.png", dpi=220)
    plt.close(fig)


def _plot_example_matrix(sequences: dict[tuple[str, str], FastaRecord]) -> None:
    rat = sequences[("rat", "Cdkn2b")]
    human = sequences[("human", "CDKN2B")]
    alignment = smith_waterman(
        rat.sequence,
        human.sequence,
        substitution_score=blosum62_score,
        gap_penalty=IMPROVED_GAP,
        normalize=True,
    )
    matrix = alignment.score_matrix
    fig, ax = plt.subplots(figsize=(8, 6))
    image = ax.imshow(matrix, cmap="magma", aspect="auto")
    ax.scatter([alignment.end_b], [alignment.end_a], color="cyan", s=45, edgecolor="black", label="best local score")
    ax.set_xlabel("Human CDKN2B/p15 sequence position")
    ax.set_ylabel("Rat Cdkn2b/p15 sequence position")
    ax.set_title("Smith-Waterman dynamic-programming matrix for p15/CDKN2B")
    ax.legend(loc="lower right")
    cbar = fig.colorbar(image, ax=ax)
    cbar.set_label("Local alignment score")
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "example_alignment_matrix.png", dpi=220)
    plt.close(fig)


def _find_cross_score(rows: list[dict[str, str]], rat_label: str, human_label: str) -> float:
    for row in rows:
        if row["rat_panel_symbol"] == rat_label and row["human_panel_symbol"] == human_label:
            return float(row["normalized_conservation"])
    return math.nan


def _panel_order(metadata: list[dict[str, str]]) -> list[str]:
    return _unique_in_order([row["panel_symbol"] for row in metadata if row["species"] == "human"])


def _metadata_for(metadata: list[dict[str, str]], panel_symbol: str, species: str) -> dict[str, str]:
    for row in metadata:
        if row["panel_symbol"] == panel_symbol and row["species"] == species:
            return row
    raise KeyError(f"Missing metadata for {species} {panel_symbol}")


def _unique_in_order(values: list[str]) -> list[str]:
    seen = set()
    result = []
    for value in values:
        if value not in seen:
            result.append(value)
            seen.add(value)
    return result


if __name__ == "__main__":
    main()
